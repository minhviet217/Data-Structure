public class DogRunner{

    public static void main(String[] args) {


        Dog fifi = new Dog("Fifi", 6.3);
        System.out.println(fifi.getName());
        System.out.println(fifi.getWeight());

    }


}
